package day4.mybatis.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class CateDto {
	private String code;
	private String name;

}
