// 작성자 : xxx

document.getElementById('join').addEventListener('click', function() {
    // alert('여기에 유효성 검증 구현하세요.')   //지우세요.
	document.forms[0].submit();
})