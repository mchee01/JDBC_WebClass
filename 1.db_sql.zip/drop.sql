-- 필요시 데이블과 시퀀스 삭제 삭제
DROP TABLE demo_member ;
DROP TABLE communityComments ;
DROP TABLE community ;
DROP SEQUENCE community_idx_seq;
DROP SEQUENCE comment_idx_seq;

DROP TABLE NEWBOOKS ;
DROP TABLE notice ;
DROP SEQUENCE notice_idx_seq;
DROP SEQUENCE newbooks_idx_seq;
